package self.pg.hybrid_multi_tenant;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HybridMultiTenantApplicationTests {

	@Test
	void contextLoads() {
	}

}
